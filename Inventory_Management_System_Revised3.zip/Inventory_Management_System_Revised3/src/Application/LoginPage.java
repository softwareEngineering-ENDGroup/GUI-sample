/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.*;

public class LoginPage extends javax.swing.JFrame {

    Connection cn=null;
    PreparedStatement ps;
    ResultSet rs;
    
    public LoginPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LPLogInAsLabel = new javax.swing.JLabel();
        LPLogInAsComboBox = new java.awt.Choice();
        LPUsernameLabel = new javax.swing.JLabel();
        LPPasswordLabel = new javax.swing.JLabel();
        LPUsernameTextField = new javax.swing.JTextField();
        LPPasswordTextField = new javax.swing.JPasswordField();
        LPCancelButton = new javax.swing.JButton();
        LPLogInButton = new javax.swing.JButton();
        LPBGLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LPLogInAsLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        LPLogInAsLabel.setText("Log in as:");
        getContentPane().add(LPLogInAsLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 90, -1));

        LPLogInAsComboBox.addItem("Administrator");
        LPLogInAsComboBox.addItem("User");
        LPLogInAsComboBox.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LPLogInAsComboBox.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        LPLogInAsComboBox.setName(""); // NOI18N
        getContentPane().add(LPLogInAsComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 130, 30));

        LPUsernameLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        LPUsernameLabel.setText("Username:");
        getContentPane().add(LPUsernameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 100, -1));

        LPPasswordLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        LPPasswordLabel.setText("Password:");
        getContentPane().add(LPPasswordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 100, -1));

        LPUsernameTextField.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        LPUsernameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LPUsernameTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(LPUsernameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 160, 220, -1));

        LPPasswordTextField.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        LPPasswordTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LPPasswordTextFieldKeyPressed(evt);
            }
        });
        getContentPane().add(LPPasswordTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 200, 220, -1));

        LPCancelButton.setBackground(new java.awt.Color(255, 255, 255));
        LPCancelButton.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        LPCancelButton.setText("CANCEL");
        LPCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LPCancelButtonActionPerformed(evt);
            }
        });
        getContentPane().add(LPCancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 250, 110, -1));

        LPLogInButton.setBackground(new java.awt.Color(255, 255, 255));
        LPLogInButton.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        LPLogInButton.setForeground(new java.awt.Color(54, 1, 3));
        LPLogInButton.setText("LOG IN");
        LPLogInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LPLogInButtonActionPerformed(evt);
            }
        });
        LPLogInButton.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LPLogInButtonKeyPressed(evt);
            }
        });
        getContentPane().add(LPLogInButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 110, -1));

        LPBGLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Application/Images/loginBg.JPG"))); // NOI18N
        LPBGLabel.setText("jLabel5");
        getContentPane().add(LPBGLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 680, 370));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void LPUsernameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LPUsernameTextFieldActionPerformed

    }//GEN-LAST:event_LPUsernameTextFieldActionPerformed

    private void LPLogInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LPLogInButtonActionPerformed

        cn=DbConnection.dbConnection();
        String sel="Select * from useraccount where username=? and password=?";
        try
        {
            ps=cn.prepareStatement(sel);
            ps.setString(1,LPUsernameTextField.getText());
            ps.setString(2,LPPasswordTextField.getText());
            rs=ps.executeQuery();
            
            if (rs.next())
            {
                JOptionPane.showMessageDialog(null, "Successful");
                new MainPage().setVisible(true);
                dispose();
            }
            else
                JOptionPane.showMessageDialog(null, "Invaled Username or Password","Access Denied", JOptionPane.ERROR_MESSAGE);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        
        
    }//GEN-LAST:event_LPLogInButtonActionPerformed

    private void LPCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LPCancelButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_LPCancelButtonActionPerformed

    private void LPLogInButtonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LPLogInButtonKeyPressed
        // TODO add your handling code here:
  
    }//GEN-LAST:event_LPLogInButtonKeyPressed

    private void LPPasswordTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LPPasswordTextFieldKeyPressed
    
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)        
        LPLogInButton.doClick();
    }//GEN-LAST:event_LPPasswordTextFieldKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LPBGLabel;
    private javax.swing.JButton LPCancelButton;
    private java.awt.Choice LPLogInAsComboBox;
    private javax.swing.JLabel LPLogInAsLabel;
    private javax.swing.JButton LPLogInButton;
    private javax.swing.JLabel LPPasswordLabel;
    private javax.swing.JPasswordField LPPasswordTextField;
    private javax.swing.JLabel LPUsernameLabel;
    private javax.swing.JTextField LPUsernameTextField;
    // End of variables declaration//GEN-END:variables

}
