/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Claudja Murawski
 */
public class PointOfSale extends javax.swing.JFrame {

    Connection cn=null;
    PreparedStatement ps;
    ResultSet rs;
 
    public PointOfSale() {
        initComponents();
        cn=DbConnection.dbConnection();
        jcomboBoxDisplayDb();
        
    }
    
    private void jcomboBoxDisplayDb()
    {
        try
        {
            String query = "Select * from productdesc";
            ps = cn.prepareStatement(query);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                String code = rs.getString("prodCode");
                posProductCodeJComboBox.addItem(code);
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        posPointOfSaleLabel = new javax.swing.JLabel();
        posBackButton = new javax.swing.JButton();
        posDateLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        PointOfSaleTable = new javax.swing.JTable();
        posProcessButton = new javax.swing.JButton();
        posDeleteButton = new javax.swing.JButton();
        posSalesAgentLabel = new javax.swing.JLabel();
        posSalesAgentTextField = new javax.swing.JTextField();
        posAddButton = new javax.swing.JButton();
        posNewTransactionButton = new javax.swing.JButton();
        posCancelButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        posDescriptionTf = new javax.swing.JTextField();
        posProductNameTf = new javax.swing.JTextField();
        posCostTf = new javax.swing.JTextField();
        posDateJCalendar = new com.toedter.calendar.JDateChooser();
        posProductCodeJComboBox = new javax.swing.JComboBox<>();
        posQuantitySpn = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        posPointOfSaleLabel.setFont(new java.awt.Font("Monospaced", 1, 36)); // NOI18N
        posPointOfSaleLabel.setText("Point of Sale");
        getContentPane().add(posPointOfSaleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, -1, -1));

        posBackButton.setBackground(new java.awt.Color(255, 255, 255));
        posBackButton.setFont(new java.awt.Font("Century Schoolbook", 1, 15)); // NOI18N
        posBackButton.setText("Back");
        posBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posBackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posBackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, -1, -1));

        posDateLabel.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        posDateLabel.setText("Date:");
        getContentPane().add(posDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        PointOfSaleTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Code", "Product Name", "Description", "Quantity", "Cost/Unit"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        PointOfSaleTable.setColumnSelectionAllowed(true);
        PointOfSaleTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(PointOfSaleTable);
        PointOfSaleTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 790, 160));

        posProcessButton.setBackground(new java.awt.Color(255, 255, 255));
        posProcessButton.setFont(new java.awt.Font("Century Schoolbook", 1, 15)); // NOI18N
        posProcessButton.setText("PROCESS");
        posProcessButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posProcessButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posProcessButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, 380, -1));

        posDeleteButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        posDeleteButton.setText("DELETE PRODUCT");
        posDeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posDeleteButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posDeleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 160, 30));

        posSalesAgentLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        posSalesAgentLabel.setForeground(new java.awt.Color(255, 255, 255));
        posSalesAgentLabel.setText("Sales Agent:");
        posSalesAgentLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(posSalesAgentLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, -1, 20));

        posSalesAgentTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(posSalesAgentTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 270, -1));

        posAddButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        posAddButton.setText("ADD PRODUCT");
        posAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posAddButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posAddButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 140, 30));

        posNewTransactionButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        posNewTransactionButton.setText("NEW TRANSACTION");
        posNewTransactionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posNewTransactionButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posNewTransactionButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, 170, 30));

        posCancelButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        posCancelButton.setText("CANCEL ORDER");
        posCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posCancelButtonActionPerformed(evt);
            }
        });
        getContentPane().add(posCancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 190, 150, 30));

        jLabel1.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jLabel1.setText("Description :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 20));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jLabel3.setText("Quantity :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, -1, -1));

        jLabel2.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jLabel2.setText("Product Name :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, 20));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jLabel4.setText("Cost :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("Century Schoolbook", 0, 14)); // NOI18N
        jLabel5.setText("Product Code :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, -1, -1));

        posDescriptionTf.setEditable(false);
        posDescriptionTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posDescriptionTfActionPerformed(evt);
            }
        });
        getContentPane().add(posDescriptionTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 240, 30));

        posProductNameTf.setEditable(false);
        posProductNameTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posProductNameTfActionPerformed(evt);
            }
        });
        getContentPane().add(posProductNameTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 190, 30));

        posCostTf.setEditable(false);
        getContentPane().add(posCostTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 100, 30));

        posDateJCalendar.setEnabled(false);
        getContentPane().add(posDateJCalendar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, -1));
        Date date = new Date();
        posDateJCalendar.setDate(date);
        posDateJCalendar.getDateEditor().setEnabled(false);

        posProductCodeJComboBox.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                posProductCodeJComboBoxPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        posProductCodeJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                posProductCodeJComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(posProductCodeJComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 190, 30));

        posQuantitySpn.setModel(new javax.swing.SpinnerNumberModel());
        getContentPane().add(posQuantitySpn, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, 60, 30));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Application/Images/pos_Bg.JPG"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 490));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void posBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posBackButtonActionPerformed
        this.dispose();
        new MainPage().setVisible(true);
    }//GEN-LAST:event_posBackButtonActionPerformed

    private void posProcessButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posProcessButtonActionPerformed
       
    }//GEN-LAST:event_posProcessButtonActionPerformed

    
    private void posAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posAddButtonActionPerformed
        
        DefaultTableModel model = (DefaultTableModel)PointOfSaleTable.getModel();
        PointOfSaleTable.setRowSelectionAllowed(true);
        model.addRow(new Object[]{posProductCodeJComboBox.getSelectedItem(), posProductNameTf.getText(),
                                  posDescriptionTf.getText(), posQuantitySpn.getValue(), posCostTf.getText(),
                                  });
       
        
    }//GEN-LAST:event_posAddButtonActionPerformed

    private void posNewTransactionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posNewTransactionButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_posNewTransactionButtonActionPerformed

    private void posCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posCancelButtonActionPerformed
         int confirmDialog = JOptionPane.showConfirmDialog(null,"Do you really want to cancelOrder","Cancel",JOptionPane.YES_NO_OPTION);
        if(confirmDialog==0)
        {
            cancelOrder();           
        }
    }//GEN-LAST:event_posCancelButtonActionPerformed

    public void cancelOrder()
    {
        DefaultTableModel dtm = (DefaultTableModel) PointOfSaleTable.getModel();
        dtm.setRowCount(0);
    }
    
    
    private void posDeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posDeleteButtonActionPerformed
         int deleteRow = PointOfSaleTable.getSelectedRow();
         if(deleteRow != -1) 
        {
            int modelIndex = jTable1.convertRowIndexToModel(deleteRow); // converts the row index in the view to the appropriate index in the model
            DefaultTableModel model = (DefaultTableModel)PointOfSaleTable.getModel();
            model.removeRow(modelIndex);
         }
    }//GEN-LAST:event_posDeleteButtonActionPerformed

    private void posDescriptionTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posDescriptionTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_posDescriptionTfActionPerformed

    private void posProductNameTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posProductNameTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_posProductNameTfActionPerformed

    private void posProductCodeJComboBoxPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_posProductCodeJComboBoxPopupMenuWillBecomeInvisible

            String sel = (String)posProductCodeJComboBox.getSelectedItem();
            String query = "Select * from productdesc where prodCode=?";
            String query1= "Select * from inventory where prodCode=?";           
        try
        {
             ps=cn.prepareStatement(query);
             ps.setString(1, sel);
             rs=ps.executeQuery();
             if(rs.next())
             {
                 String display1 = rs.getString("prodName");
                 posProductNameTf.setText(display1);
                 String display2 = rs.getString("description");
                 posDescriptionTf.setText(display2);                                
             }
           
            ps=cn.prepareStatement(query1);
            ps.setString(1, sel);
            rs=ps.executeQuery();
             if(rs.next())
             {                
                 String display3 = rs.getString("sellPrice");
                 posCostTf.setText(display3);                
                 
                 String sp = rs.getString("stock");
                 int spinMax = Integer.parseInt(sp);
                 SpinnerModel sm = new SpinnerNumberModel(0, 0, spinMax, 1);               
                 posQuantitySpn.setModel(sm);
             }  
        }
        catch(Exception e)
        {
             JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_posProductCodeJComboBoxPopupMenuWillBecomeInvisible

    private void posProductCodeJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_posProductCodeJComboBoxActionPerformed

    }//GEN-LAST:event_posProductCodeJComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PointOfSale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PointOfSale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PointOfSale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PointOfSale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PointOfSale().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable PointOfSaleTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton posAddButton;
    private javax.swing.JButton posBackButton;
    private javax.swing.JButton posCancelButton;
    private javax.swing.JTextField posCostTf;
    private com.toedter.calendar.JDateChooser posDateJCalendar;
    private javax.swing.JLabel posDateLabel;
    private javax.swing.JButton posDeleteButton;
    private javax.swing.JTextField posDescriptionTf;
    private javax.swing.JButton posNewTransactionButton;
    private javax.swing.JLabel posPointOfSaleLabel;
    private javax.swing.JButton posProcessButton;
    private javax.swing.JComboBox<String> posProductCodeJComboBox;
    private javax.swing.JTextField posProductNameTf;
    private javax.swing.JSpinner posQuantitySpn;
    private javax.swing.JLabel posSalesAgentLabel;
    private javax.swing.JTextField posSalesAgentTextField;
    // End of variables declaration//GEN-END:variables
}
