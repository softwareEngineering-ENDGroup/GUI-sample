/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author db2admin
 */
@Entity
@Table(name = "userinformation", catalog = "inventory", schema = "")
@NamedQueries({
    @NamedQuery(name = "Userinformation_1.findAll", query = "SELECT u FROM Userinformation_1 u")
    , @NamedQuery(name = "Userinformation_1.findByUserType", query = "SELECT u FROM Userinformation_1 u WHERE u.userType = :userType")
    , @NamedQuery(name = "Userinformation_1.findByUserId", query = "SELECT u FROM Userinformation_1 u WHERE u.userId = :userId")
    , @NamedQuery(name = "Userinformation_1.findByLastName", query = "SELECT u FROM Userinformation_1 u WHERE u.lastName = :lastName")
    , @NamedQuery(name = "Userinformation_1.findByFirstName", query = "SELECT u FROM Userinformation_1 u WHERE u.firstName = :firstName")
    , @NamedQuery(name = "Userinformation_1.findByAddress", query = "SELECT u FROM Userinformation_1 u WHERE u.address = :address")
    , @NamedQuery(name = "Userinformation_1.findByContactNo", query = "SELECT u FROM Userinformation_1 u WHERE u.contactNo = :contactNo")
    , @NamedQuery(name = "Userinformation_1.findByPosition", query = "SELECT u FROM Userinformation_1 u WHERE u.position = :position")
    , @NamedQuery(name = "Userinformation_1.findByUserName", query = "SELECT u FROM Userinformation_1 u WHERE u.userName = :userName")})
public class Userinformation_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "userType")
    private String userType;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "userId")
    private Integer userId;
    @Basic(optional = false)
    @Column(name = "lastName")
    private String lastName;
    @Basic(optional = false)
    @Column(name = "firstName")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "contactNo")
    private long contactNo;
    @Basic(optional = false)
    @Column(name = "position")
    private String position;
    @Basic(optional = false)
    @Column(name = "userName")
    private String userName;

    public Userinformation_1() {
    }

    public Userinformation_1(Integer userId) {
        this.userId = userId;
    }

    public Userinformation_1(Integer userId, String userType, String lastName, String firstName, String address, long contactNo, String position, String userName) {
        this.userId = userId;
        this.userType = userType;
        this.lastName = lastName;
        this.firstName = firstName;
        this.address = address;
        this.contactNo = contactNo;
        this.position = position;
        this.userName = userName;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        String oldUserType = this.userType;
        this.userType = userType;
        changeSupport.firePropertyChange("userType", oldUserType, userType);
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        Integer oldUserId = this.userId;
        this.userId = userId;
        changeSupport.firePropertyChange("userId", oldUserId, userId);
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        String oldLastName = this.lastName;
        this.lastName = lastName;
        changeSupport.firePropertyChange("lastName", oldLastName, lastName);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        String oldFirstName = this.firstName;
        this.firstName = firstName;
        changeSupport.firePropertyChange("firstName", oldFirstName, firstName);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public long getContactNo() {
        return contactNo;
    }

    public void setContactNo(long contactNo) {
        long oldContactNo = this.contactNo;
        this.contactNo = contactNo;
        changeSupport.firePropertyChange("contactNo", oldContactNo, contactNo);
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        String oldPosition = this.position;
        this.position = position;
        changeSupport.firePropertyChange("position", oldPosition, position);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        String oldUserName = this.userName;
        this.userName = userName;
        changeSupport.firePropertyChange("userName", oldUserName, userName);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userId != null ? userId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userinformation_1)) {
            return false;
        }
        Userinformation_1 other = (Userinformation_1) object;
        if ((this.userId == null && other.userId != null) || (this.userId != null && !this.userId.equals(other.userId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Application.Userinformation_1[ userId=" + userId + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
