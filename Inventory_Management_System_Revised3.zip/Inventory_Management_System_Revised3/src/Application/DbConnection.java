package Application;
import java.sql.*;
import javax.swing.*;

public class DbConnection 
{
 
    public ResultSet rs;
    
    public static Connection dbConnection()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/inventory","root","");
            return cn;
          
          
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
}
