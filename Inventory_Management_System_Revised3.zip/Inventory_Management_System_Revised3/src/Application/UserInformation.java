/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.DbUtils;
import Application.MainPage;
import java.math.BigInteger;
import javax.swing.table.DefaultTableModel;

public class UserInformation extends javax.swing.JFrame {

    Connection cn=null;
    PreparedStatement ps;
    ResultSet rs;
    String id;
    
    
    public UserInformation() {
        initComponents();
        cn=DbConnection.dbConnection();
        id="";
        displayTable();
    }

    
public void displayTable(){    
    
    StaffInformationTable.setDefaultEditor(Object.class, null);
    try 
		{
			String query = "SELECT ui.userType, ui.userId, ui.lastName, ui.firstName, ui.address, ui.contactNo, ui.position, ua.userName, ua.password FROM userinformation ui INNER JOIN useraccount ua ON ui.userName=ua.userName";
			ps = cn.prepareStatement(query);
			rs = ps.executeQuery();
			StaffInformationTable.setModel(DbUtils.resultSetToTableModel(rs));
                    
		} catch (Exception e) {
			e.printStackTrace();
		}
            
          
}

public void autoEmployeeCode()
    {
        try{
            String query="SELECT userId FROM userinformation ORDER BY userId DESC LIMIT 1";
            ps=cn.prepareStatement(query);
            rs=ps.executeQuery();
           
            if(rs.next())
            {
                String ui = rs.getString("userId");
                int ln = ui.length();
                String stxt = ui.substring(0,3);
                String snum = ui.substring(3,ln);
                int n = Integer.parseInt(snum);
                n++;
                snum = Integer.toString(n);
                id = stxt+snum;
            }
            else
            {
               id ="EMP2908";
            }
        }   
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        StaffInfoLabel = new javax.swing.JLabel();
        StaffInfoAddNewUserButton = new javax.swing.JButton();
        StaffInfoCancelButton = new javax.swing.JButton();
        StaffInfoDeleteUserButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        StaffInformationTable = new javax.swing.JTable();
        StaffInfoBackButton = new javax.swing.JButton();
        StaffInfoUserTypeLabel = new javax.swing.JLabel();
        StaffInfoNameLabel = new javax.swing.JLabel();
        StaffInfoFirstNameTextField = new javax.swing.JTextField();
        StaffInfoFirstNameLabel = new javax.swing.JLabel();
        StaffInfoUserTypeComboBox = new java.awt.Choice();
        StaffInfoAddressLabel = new javax.swing.JLabel();
        StaffInfoPositionTextField = new java.awt.Choice();
        StaffInfoContactNoLabel = new javax.swing.JLabel();
        StaffInfoContactNoTextField = new javax.swing.JTextField();
        StaffInfoSearchLabel = new javax.swing.JLabel();
        StaffInfoUserNameLabel = new javax.swing.JLabel();
        StaffInfoUpdateUserButton = new javax.swing.JButton();
        StaffInfoPasswordLabel = new javax.swing.JLabel();
        StaffInfoConfirmPasswordLabel = new javax.swing.JLabel();
        StaffInfoPasswordTextField = new javax.swing.JPasswordField();
        StaffInfoConfirmPasswordTextField = new javax.swing.JPasswordField();
        StaffInfoPositionLabel = new javax.swing.JLabel();
        StaffInfoNameTextField = new javax.swing.JTextField();
        StaffInfoLastNameLabel = new javax.swing.JLabel();
        StaffInfoStreetLabel = new javax.swing.JLabel();
        StaffInfoCityLabel = new javax.swing.JLabel();
        StaffInfoBaranggayLabel = new javax.swing.JLabel();
        StaffInfoSearchTextField = new javax.swing.JTextField();
        StaffInfoAddressTextField = new javax.swing.JTextField();
        StaffInfoUserNameTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        StaffInfoLabel.setFont(new java.awt.Font("Monospaced", 1, 30)); // NOI18N
        StaffInfoLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoLabel.setText("Staff Information");
        getContentPane().add(StaffInfoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        StaffInfoAddNewUserButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        StaffInfoAddNewUserButton.setText("ADD NEW USER");
        StaffInfoAddNewUserButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoAddNewUserButtonActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoAddNewUserButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 290, 140, 30));

        StaffInfoCancelButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        StaffInfoCancelButton.setText("CANCEL");
        StaffInfoCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoCancelButtonActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoCancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 350, 140, 30));

        StaffInfoDeleteUserButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        StaffInfoDeleteUserButton.setText("DELETE  USER");
        StaffInfoDeleteUserButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoDeleteUserButtonActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoDeleteUserButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 410, 140, 30));

        StaffInformationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "USER TYPE", "USER ID", "LAST NAME", "FIRST NAME", "ADDRESS", "CONTACT NO", "POSITION", "USER NAME", "PASSWORD"
            }
        ));
        StaffInformationTable.getTableHeader().setReorderingAllowed(false);
        StaffInformationTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                StaffInformationTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(StaffInformationTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 820, 170));

        StaffInfoBackButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        StaffInfoBackButton.setText("BACK");
        StaffInfoBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoBackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoBackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 10, -1, -1));

        StaffInfoUserTypeLabel.setBackground(new java.awt.Color(0, 0, 0));
        StaffInfoUserTypeLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoUserTypeLabel.setText("User Type:");
        getContentPane().add(StaffInfoUserTypeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, 20));

        StaffInfoNameLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoNameLabel.setText("Name:");
        getContentPane().add(StaffInfoNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, -1, -1));

        StaffInfoFirstNameTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoFirstNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, 220, -1));

        StaffInfoFirstNameLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        StaffInfoFirstNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoFirstNameLabel.setText("First Name:");
        getContentPane().add(StaffInfoFirstNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, -1, 20));

        StaffInfoUserTypeComboBox.addItem("");
        StaffInfoUserTypeComboBox.addItem("Male");
        StaffInfoUserTypeComboBox.addItem("Female");
        StaffInfoUserTypeComboBox.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoUserTypeComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 150, -1));

        StaffInfoAddressLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoAddressLabel.setText("Address:");
        getContentPane().add(StaffInfoAddressLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, -1, -1));

        StaffInfoPositionTextField.addItem("");
        StaffInfoPositionTextField.addItem("Administrator");
        StaffInfoPositionTextField.addItem("Employee");
        StaffInfoPositionTextField.setFont(new java.awt.Font("Dialog", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoPositionTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 470, 150, -1));

        StaffInfoContactNoLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoContactNoLabel.setText("Contact No:");
        getContentPane().add(StaffInfoContactNoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, -1, 20));

        StaffInfoContactNoTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoContactNoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 430, 150, -1));

        StaffInfoSearchLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 15)); // NOI18N
        StaffInfoSearchLabel.setText("Search:");
        getContentPane().add(StaffInfoSearchLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, -1, -1));

        StaffInfoUserNameLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoUserNameLabel.setText("User Name:");
        getContentPane().add(StaffInfoUserNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 420, 90, -1));

        StaffInfoUpdateUserButton.setFont(new java.awt.Font("Century Schoolbook", 1, 12)); // NOI18N
        StaffInfoUpdateUserButton.setText("UPDATE USER");
        StaffInfoUpdateUserButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoUpdateUserButtonActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoUpdateUserButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 470, 140, 30));

        StaffInfoPasswordLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoPasswordLabel.setText("Password:");
        getContentPane().add(StaffInfoPasswordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, -1, -1));

        StaffInfoConfirmPasswordLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoConfirmPasswordLabel.setText("Confirm Password:");
        getContentPane().add(StaffInfoConfirmPasswordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 480, -1, -1));

        StaffInfoPasswordTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoPasswordTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 450, 180, -1));

        StaffInfoConfirmPasswordTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoConfirmPasswordTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 480, 180, -1));

        StaffInfoPositionLabel.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        StaffInfoPositionLabel.setText("Position:");
        getContentPane().add(StaffInfoPositionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 470, -1, -1));

        StaffInfoNameTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        getContentPane().add(StaffInfoNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, 200, -1));

        StaffInfoLastNameLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        StaffInfoLastNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoLastNameLabel.setText("Last Name:");
        getContentPane().add(StaffInfoLastNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, -1, -1));

        StaffInfoStreetLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        StaffInfoStreetLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoStreetLabel.setText("Street:");
        getContentPane().add(StaffInfoStreetLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, -1, -1));

        StaffInfoCityLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        StaffInfoCityLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoCityLabel.setText("City:");
        getContentPane().add(StaffInfoCityLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 370, -1, -1));

        StaffInfoBaranggayLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        StaffInfoBaranggayLabel.setForeground(new java.awt.Color(255, 255, 255));
        StaffInfoBaranggayLabel.setText("Baranggay:");
        getContentPane().add(StaffInfoBaranggayLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, -1, -1));
        getContentPane().add(StaffInfoSearchTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 230, -1));

        StaffInfoAddressTextField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        getContentPane().add(StaffInfoAddressTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 490, 30));

        StaffInfoUserNameTextField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        StaffInfoUserNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StaffInfoUserNameTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(StaffInfoUserNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 420, 180, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Application/Images/user_infoBG.PNG"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
       
    private void StaffInfoBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoBackButtonActionPerformed
        this.dispose();
        new MainPage().setVisible(true);
    }//GEN-LAST:event_StaffInfoBackButtonActionPerformed

    private void StaffInfoAddNewUserButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoAddNewUserButtonActionPerformed

        {			
                        
			if(StaffInfoFirstNameTextField.getText().isEmpty() || StaffInfoNameTextField.getText().isEmpty() ||
					StaffInfoUserTypeComboBox.getSelectedItem().isEmpty() ||  StaffInfoAddressTextField.getText().isEmpty() ||
					StaffInfoContactNoTextField.getText().isEmpty() || StaffInfoPositionTextField.getSelectedItem().isEmpty() ||
					StaffInfoUserNameTextField.getText().isEmpty() || StaffInfoPasswordTextField.getText().isEmpty() || StaffInfoConfirmPasswordTextField.getText().isEmpty() )
			{
				JOptionPane.showMessageDialog(null,"Please Fill up All the Information");
			}
			else{
				saveToDatabase();
			}
		}
    }//GEN-LAST:event_StaffInfoAddNewUserButtonActionPerformed

    
    public void saveToDatabase(){
        
         cn = DbConnection.dbConnection();
        try {               
               
            
            String insertAcc="INSERT INTO useraccount(userName,password) VALUES (?,?) ";
            ps = cn.prepareStatement(insertAcc);
            
            ps.setString(1, StaffInfoUserNameTextField.getText());
            ps.setString(2, StaffInfoPasswordTextField.getText());
            ps.execute();           
            
            autoEmployeeCode();
            String insertInfo="INSERT INTO userinformation(userType, userId, lastName, firstName, address, contactNo, position,username) VALUES (?,?,?,?,?,?,?,?)"; 
            ps = cn.prepareStatement(insertInfo);
                  
            ps.setString(1, StaffInfoUserTypeComboBox.getSelectedItem().toString());
            ps.setString(2, id);
            ps.setString(3, StaffInfoNameTextField.getText());		        
            ps.setString(4, StaffInfoFirstNameTextField.getText());
            ps.setString(5, StaffInfoAddressTextField.getText());
            ps.setString(6, StaffInfoContactNoTextField.getText());
            ps.setString(7, StaffInfoPositionTextField.getSelectedItem().toString());  
            ps.setString(8, StaffInfoUserNameTextField.getText());
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Saved");   
            
            textFieldSetEmpty();

            
		} catch (SQLException e) 
                {
                    JOptionPane.showMessageDialog(null, e);
		}
       
        displayTable();
    } 
    public void textFieldSetEmpty()
    {
            StaffInfoUserTypeComboBox.select("");
            StaffInfoFirstNameTextField.setText("");
            StaffInfoNameTextField.setText("");
            StaffInfoAddressTextField.setText("");
            StaffInfoContactNoTextField.setText("");
            StaffInfoPositionTextField.select("");
            StaffInfoUserNameTextField.setText("");           
            StaffInfoConfirmPasswordTextField.setText("");
            StaffInfoPasswordTextField.setText("");
    }
    
    private void StaffInfoCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoCancelButtonActionPerformed
        textFieldSetEmpty();
    }//GEN-LAST:event_StaffInfoCancelButtonActionPerformed

    private void StaffInfoUserNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoUserNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StaffInfoUserNameTextFieldActionPerformed

    private void StaffInfoDeleteUserButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoDeleteUserButtonActionPerformed
        
        int confirmDialog = JOptionPane.showConfirmDialog(null,"Do you really want to delete","Delete",JOptionPane.YES_NO_OPTION);
        if(confirmDialog==0)
        {
            deleteUser();           
        }
          
    }//GEN-LAST:event_StaffInfoDeleteUserButtonActionPerformed

    private void StaffInformationTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StaffInformationTableMouseClicked
        tableToTextfield();
    }//GEN-LAST:event_StaffInformationTableMouseClicked

    private void StaffInfoUpdateUserButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StaffInfoUpdateUserButtonActionPerformed
        int confirmDialog = JOptionPane.showConfirmDialog(null,"Are you sure you want to change the following info","Updated",JOptionPane.YES_NO_OPTION);
        if(confirmDialog==0)
        {
            updateUser();           
        }
    }//GEN-LAST:event_StaffInfoUpdateUserButtonActionPerformed
   
    public void tableToTextfield()
    {
        int i = StaffInformationTable.getSelectedRow();
        DefaultTableModel model= (DefaultTableModel)StaffInformationTable.getModel();
        
        StaffInfoUserTypeComboBox.select(model.getValueAt(i,0).toString());
        StaffInfoNameTextField.setText(model.getValueAt(i,2).toString());
        StaffInfoFirstNameTextField.setText(model.getValueAt(i,3).toString());
        StaffInfoAddressTextField.setText(model.getValueAt(i,4).toString());
        StaffInfoContactNoTextField.setText(model.getValueAt(i,5).toString());
        StaffInfoPositionTextField.select(model.getValueAt(i,6).toString());
        StaffInfoUserNameTextField.setText(model.getValueAt(i,7).toString());
        StaffInfoPasswordTextField.setText(model.getValueAt(i,8).toString());
        
        
    }

    public void deleteUser()
    {
        cn = DbConnection.dbConnection();
     
        try
        {
            String delEmp = "DELETE FROM userinformation WHERE userName=?";
            ps = cn.prepareStatement(delEmp);
            ps.setString(1, StaffInfoUserNameTextField.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "delete successfully");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }

       public void updateUser()
    {
        cn=DbConnection.dbConnection();
        try{

            String value1 = StaffInfoUserTypeComboBox.getSelectedItem();
            String value2 = StaffInfoNameTextField.getText();
            String value3 = StaffInfoFirstNameTextField.getText();
            String value4 = StaffInfoAddressTextField.getText();
            String value5 = StaffInfoContactNoTextField.getText();
            String value6 = StaffInfoPositionTextField.getSelectedItem();
            String value7 = StaffInfoUserNameTextField.getText();
            String value8 = StaffInfoPasswordTextField.getText();

            String accSql="update useraccount set userName = '"+value7+"',password='"+value8+"'where userName = '"+value7+"'";
            ps=cn.prepareStatement(accSql);
            ps.executeUpdate();
            
            String sql="Update userinformation set userType ='"+value1+"',"
                    + "firstName = '"+value2+"',"
                    + "lastName = '"+value3+"', "
                    + "address = '"+value4+"', "
                    + "contactNo = '"+value5+"',"
                    + "position = '"+value6+"' ,"
                    + "userName = '"+value7+"' "
                    + "where userName = '"+value7+"'";
            
            ps=cn.prepareStatement(sql);
            ps.executeUpdate();
           
           JOptionPane.showMessageDialog(null,"Updated");  
            }
                catch(SQLException e){
                        JOptionPane.showMessageDialog(null,e);
                    }
        displayTable();
    }                                                         

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserInformation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton StaffInfoAddNewUserButton;
    private javax.swing.JLabel StaffInfoAddressLabel;
    private javax.swing.JTextField StaffInfoAddressTextField;
    private javax.swing.JButton StaffInfoBackButton;
    private javax.swing.JLabel StaffInfoBaranggayLabel;
    private javax.swing.JButton StaffInfoCancelButton;
    private javax.swing.JLabel StaffInfoCityLabel;
    private javax.swing.JLabel StaffInfoConfirmPasswordLabel;
    private javax.swing.JPasswordField StaffInfoConfirmPasswordTextField;
    private javax.swing.JLabel StaffInfoContactNoLabel;
    private javax.swing.JTextField StaffInfoContactNoTextField;
    private javax.swing.JButton StaffInfoDeleteUserButton;
    private javax.swing.JLabel StaffInfoFirstNameLabel;
    private javax.swing.JTextField StaffInfoFirstNameTextField;
    private javax.swing.JLabel StaffInfoLabel;
    private javax.swing.JLabel StaffInfoLastNameLabel;
    private javax.swing.JLabel StaffInfoNameLabel;
    private javax.swing.JTextField StaffInfoNameTextField;
    private javax.swing.JLabel StaffInfoPasswordLabel;
    private javax.swing.JPasswordField StaffInfoPasswordTextField;
    private javax.swing.JLabel StaffInfoPositionLabel;
    private java.awt.Choice StaffInfoPositionTextField;
    private javax.swing.JLabel StaffInfoSearchLabel;
    private javax.swing.JTextField StaffInfoSearchTextField;
    private javax.swing.JLabel StaffInfoStreetLabel;
    private javax.swing.JButton StaffInfoUpdateUserButton;
    private javax.swing.JLabel StaffInfoUserNameLabel;
    private javax.swing.JTextField StaffInfoUserNameTextField;
    private java.awt.Choice StaffInfoUserTypeComboBox;
    private javax.swing.JLabel StaffInfoUserTypeLabel;
    private javax.swing.JTable StaffInformationTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
